Android integrating Camera feature using in-build camera app.

[Tutorial](https://www.androidhive.info/2013/09/android-working-with-camera-api/)

[Apk](http://download.androidhive.info/apk/android-camera.apk)

![Android Camera API](https://www.androidhive.info/wp-content/uploads/2018/05/android-camera-tutorial-capture-image-record-video.png)